<?php
require ("functions.php");
include "admin-header.php";

$urun_id = $_GET['item_id'] ?? 0;
foreach($product->veriGetir() as $urun):
    if($urun['item_id'] == $urun_id):

      if($_SERVER['REQUEST_METHOD'] == "POST"){
        if(isset($_POST['telefon-degistir'])) {
          $product->telefonGuncelle($urun_id,$_POST['marka'],$_POST['model'],$_POST['fiyat'],$_POST['resim']);
        }
      }

      $markalar = $product->veriGetir("marka");
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Urun Duzenle</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Ana Sayfa</a></li>
              <li class="breadcrumb-item active">Urun Duzenle</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-6">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Urun</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                  <i class="fas fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <form method="post">
                <div class="form-group">
                  <label for="marka">Marka</label>
                  <select name="marka" class="form-control custom-select">
                    <option disabled>Select one</option>
                    <?php foreach ($markalar as $marka) {
                      if ($marka['marka_ad'] == $urun['item_brand'])
                        echo "<option selected>" . $marka['marka_ad'] . "</option>";
                      else
                        echo "<option>" . $marka['marka_ad'] . "</option>";
                    }?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="model">Model</label>
                  <input type="text" name="model" class="form-control" value="<?php echo $urun['item_name'];?>">
                </div>
                <div class="form-group">
                  <label for="fiyat">Fiyat</label>
                  <input type="text" name="fiyat" class="form-control" value="<?php echo $urun['item_price'];?>">
                </div>
                <div class="form-group">
                  <label for="resim">Resim</label>
                  <input type="text" name="resim" class="form-control" value="<?php echo $urun['item_image'];?>">
                </div>
                <div class="form-group">
                  <button type="submit" class="btn btn-success float-right" name="telefon-degistir">
                    Değişiklikleri Kaydet
                  </button>
                </div>
              </form>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php
      include "admin-footer.php";

    endif;
   endforeach;
?>
