<?php


class DBBaglanti
{
  protected $host = 'localhost';
  protected $user = 'root';
  protected $password = '';
  protected $database = 'e-commerce';

  public $con = null;
  public function __construct()
  {
    $host = $this->host;
    $user = $this->user;
    $password = $this->password;
    $database = $this->database;

    $this->con = mysqli_connect($host, $user, $password, $database);

    if ($this->con->connect_error){
      echo "Basarisiz".$this->con->connect_error;
    }

  }

  public function __destruct()
  {
    // TODO: Implement __destruct() method.
    $this->closeConnection();
  }

  protected function closeConnection(){
    if($this->con != null){
      $this->con->close();
      $this->con = null;
    }
  }
}
