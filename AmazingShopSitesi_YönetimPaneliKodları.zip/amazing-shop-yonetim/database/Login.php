<?php


class Login
{
  public $db = null;

  public function __construct(DBBaglanti $db)
  {
    if(!isset($db->con))
      return null;

    $this->db = $db;
  }

  public function getUsers(){
    $sonuc = $this->db->con->query("SELECT * FROM admin");

    $sonucDizi = array();

    while($eleman = mysqli_fetch_array($sonuc,MYSQLI_ASSOC)){
      $sonucDizi[] = $eleman;
    }

    return $sonucDizi;
  }

}