<?php


class Urun
{
  public $db = null;

  public function __construct(DBBaglanti $db){
    if(!isset($db->con))
      return null;
    $this->db = $db;
  }

  public function veriGetir($table = "product"){
    $sonuc = $this->db->con->query("SELECT * FROM {$table}");

    $sonucDizi = array();

    while($eleman = mysqli_fetch_array($sonuc,MYSQLI_ASSOC)){
      $sonucDizi[] = $eleman;
    }

    return $sonucDizi;
  }


  public function urunGetir($item_id=null, $table="product"){
    if (isset($item_id)){
      $sonuc = $this->db->con->query("SELECT * FROM {$table} WHERE item_id = {$item_id}");
      $sonucDizi = array();

      while($eleman = mysqli_fetch_array($sonuc,MYSQLI_ASSOC)){
        $sonucDizi[] = $eleman;
      }

      return $sonucDizi;
    }
  }


  public function telefonEkle($marka, $model, $fiyat, $resim)
  {
    if (!empty($marka) && !empty($model) && !empty($fiyat) && !empty($resim)) {
      $sql = "INSERT INTO product (item_brand,item_name,item_price,item_image)VALUES ('$marka','$model','$fiyat','$resim')";
      $sonuc = $this->db->con->query($sql);
      header("Location: urun-admin.php");
      return $sonuc;
    }
  }

  public function telefonGuncelle($urunid, $marka, $model, $fiyat, $resim)
  {
    if (!empty($marka) && !empty($model) && !empty($fiyat) && !empty($resim)) {
      $sql = "UPDATE product SET item_brand = '$marka', item_name = '$model', item_price = $fiyat, item_image = '$resim'
                WHERE item_id =$urunid";
      $sonuc = $this->db->con->query($sql);
      header("Location: urun-admin.php");
      return $sonuc;
    }
  }

  public function telefonSil($urunid)
  {
    if (!empty($urunid)) {
      $sql = "DELETE FROM product WHERE item_id = $urunid";
      $sonuc = $this->db->con->query($sql);
      return $sonuc;
    }
  }

  public function markaEkle($marka)
  {
    if (!empty($marka)) {
      $sql = "INSERT INTO marka (marka_ad)VALUES ('$marka')";
      $sonuc = $this->db->con->query($sql);
      header("Location: markalar.php");
      return $sonuc;
    }
  }

  public function markaGuncelle($id, $marka)
  {
    if (!empty($marka)) {
      $sql = "UPDATE marka SET marka_ad = '$marka' WHERE id = $id";
      $sonuc = $this->db->con->query($sql);
      return $sonuc;
    }
  }

  public function markaSil($id)
  {
    if (!empty($id)) {
      $sql = "DELETE FROM marka WHERE id = $id";
      $sonuc = $this->db->con->query($sql);
      return $sonuc;
    }
  }

}