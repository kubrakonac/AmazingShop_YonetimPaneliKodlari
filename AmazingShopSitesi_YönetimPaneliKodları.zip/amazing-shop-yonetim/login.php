<?php
include "admin-header.php";
session_start();
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
  echo "Session acik";
  header("location: admin.php");
  exit;
}

// Include config file
require "functions.php";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

  $users = $loggin->getUsers();

  if(!empty($_POST['username'])&& !empty($_POST['password'])){
    foreach ($users as $user){
      if($user['user_name'] == $_POST['username'] && $user['password'] == $_POST['password']){
          $_SESSION["loggedin"] = true;
          $_SESSION["username"] = $user['user_name'];
        header("location: admin.php");
      }
    }
  }

}


?>
<div class="content-wrapper">
  <div id="login-page" class="col-md-6 p-5">
    <h2>Login</h2>
    <p>Please fill in your credentials to login.</p>
    <form action="" method="post">
      <div class="form-group ">
        <label>Username</label>
        <input type="text" name="username" class="form-control">
        <span class="help-block"></span>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" class="form-control">
        <span class="help-block"></span>
      </div>
      <div class="form-group">
        <input type="submit" class="btn btn-primary" value="Login">
      </div>
    </form>
  </div>
</div>


<?php
include "admin-footer.php";
?>