<?php
require ("functions.php");
include "admin-header.php";
include "sessioncontrol.php";

if($_SERVER['REQUEST_METHOD'] == "POST"){
  if(isset($_POST['marka-ekle'])) {
    $product->markaEkle($_POST['marka']);
  }
}
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Marka Ekle</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Ana Sayfa</a></li>
              <li class="breadcrumb-item active">Marka Ekle</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-6">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Marka</h3>
            </div>
            <div class="card-body">
              <form method="post">
                <div class="form-group">
                  <label for="marka">Marka</label>
                  <input type="text" name="marka" class="form-control">
                </div>
                <div class="form-group">
                  <button type="submit" class="btn btn-success float-right" name="marka-ekle">
                    Marka Ekle
                  </button>
                </div>
              </form>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>

      </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php
include "admin-footer.php";