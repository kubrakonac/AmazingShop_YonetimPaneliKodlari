<?php
require ("functions.php");
include "admin-header.php";
include "sessioncontrol.php";

$markalar = $product->veriGetir("marka");
?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Markalar</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Anasayfa</a></li>
              <li class="breadcrumb-item active">Markalar</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">

        <div class="card-body p-0">
          <table class="table table-striped table-hover projects">
            <thead>
            <tr>
              <th style="width: 1%">
                id
              </th>
              <th style="width: 20%">
                Marka
              </th>
              <th style="width: 20%">
              </th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($markalar as $marka){ ?>
              <tr>
                <td>
                  <?php echo $marka['id']?>
                </td>
                <td>
                  <?php echo $marka['marka_ad']?>
                </td>
                <td class="project-actions text-right">
                  <a class="btn btn-info btn-sm" href="<?php echo 'marka-edit.php?marka_id='.$marka['id'] ?>">
                    <i class="fas fa-pencil-alt">
                    </i>
                    Edit
                  </a>
                  <a class="btn btn-danger btn-sm" href="<?php echo 'marka-sil.php?marka_id='.$marka['id'] ?>">
                    <i class="fas fa-trash">
                    </i>
                    Delete
                  </a>
                </td>
              </tr>
            <?php }?>
            </tbody>
          </table>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->




  <!-- ./wrapper -->
<?php
include "admin-footer.php";