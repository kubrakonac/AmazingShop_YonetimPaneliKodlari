<?php
require ("functions.php");
include "admin-header.php";

$marka_id = $_GET['marka_id'] ?? 0;
foreach($product->veriGetir("marka") as $marka):
  if($marka['id'] == $marka_id):

    if($_SERVER['REQUEST_METHOD'] == "POST"){
      if(isset($_POST['marka-degistir'])) {
        $product->markaGuncelle($marka_id,$_POST['marka']);
      }
      header("Location: markalar.php");
    }
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Marka Duzenle</h1>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Ana Sayfa</a></li>
                <li class="breadcrumb-item active">Marka Duzenle</li>
              </ol>
            </div>
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="row">
          <div class="col-md-6">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Urun</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <form method="post">
                  <div class="form-group">
                    <label for="marka">Marka</label>
                    <input type="text" name="marka" class="form-control" value="<?php echo $marka['marka_ad'];?>">
                  </div>
                  <div class="form-group">
                    <button type="submit" class="btn btn-success float-right" name="marka-degistir">
                      Değişiklikleri Kaydet
                    </button>
                  </div>
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->


    <?php
    include "admin-footer.php";

  endif;
endforeach;
?>
