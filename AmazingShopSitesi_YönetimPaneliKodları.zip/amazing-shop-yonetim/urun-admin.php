<?php
require ("functions.php");
include "admin-header.php";
include "sessioncontrol.php";

$tumUrunler = $product->veriGetir();
?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Urunler</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Anasayfa</a></li>
              <li class="breadcrumb-item active">Urunler</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">

        <div class="card-body p-0">
          <table class="table table-striped table-hover projects">
            <thead>
              <tr>
                <th style="width: 1%">
                  id
                </th>
                <th style="width: 20%">
                  Marka
                </th>
                <th style="width: 30%">
                  Model
                </th>
                <th>
                  Fiyat
                </th>
                <th style="width: 8%" class="text-center">
                  Eklenme Tarihi
                </th>
                <th style="width: 20%">
                </th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($tumUrunler as $urun){ ?>
                <tr>
                <td>
                  <?php echo $urun['item_id']?>
                </td>
                <td>
                  <?php echo $urun['item_brand']?>
                </td>
                <td>
                  <?php echo $urun['item_name']?>
                </td>
                <td>
                  $<?php echo $urun['item_price']?>
                </td>
                <td>
                  <?php echo $urun['item_register']?>
                </td>
                <td class="project-actions text-right">
                  <a class="btn btn-primary btn-sm" href="<?php echo 'urun-detay.php?item_id='.$urun['item_id'];?>">
                    <i class="fas fa-folder">
                    </i>
                    View
                  </a>
                  <a class="btn btn-info btn-sm" href="<?php echo 'urun-degistir.php?item_id='.$urun['item_id'];?>">
                    <i class="fas fa-pencil-alt">
                    </i>
                    Edit
                  </a>
                  <a class="btn btn-danger btn-sm" href="<?php echo 'telefon-sil.php?item_id='.$urun['item_id']; ?>">
                    <i class="fas fa-trash">
                    </i>
                    Delete
                  </a>
                </td>
              </tr>
              <?php }?>
            </tbody>
          </table>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->




<!-- ./wrapper -->
<?php
include "admin-footer.php";