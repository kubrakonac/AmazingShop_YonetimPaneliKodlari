<?php

require ("functions.php");
$urun_id = $_GET['item_id'] ?? 0;
$product->telefonSil($urun_id);
header("Location: urun-admin.php");