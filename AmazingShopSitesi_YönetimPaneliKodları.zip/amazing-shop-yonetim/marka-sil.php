<?php

require ("functions.php");
$marka_id = $_GET['marka_id'] ?? 0;
$product->markaSil($marka_id);
header("Location: markalar.php");