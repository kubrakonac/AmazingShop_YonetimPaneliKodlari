<?php
session_start();
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
}
else
{
  echo "Session kapali";
  header("location: login.php");
  exit;
}