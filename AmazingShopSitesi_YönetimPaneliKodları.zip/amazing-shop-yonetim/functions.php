<?php
require("database/DBBaglanti.php");

require("database/Urun.php");

require ("database/Login.php");

$db = new DBBaglanti();
$product = new Urun($db);
$urunler = $product->veriGetir();
$loggin = new Login($db);

